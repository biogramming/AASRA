#!/usr/bin/env python
"""
Calculate and plot the correlation graph between two files.

Copyright (C) 2016-2021 Chong Tang, Yeming Xie

This program is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 1 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
"""
__version__ = '1.0.0'
__author__ = 'Yeming Xie'
__date__ = 'Mon Feb 22 17:41:21 CST 2021'

import re
import operator
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['agg.path.chunksize'] = 10000
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import math
import subprocess
import re
import os
import argparse
import random


parser = argparse.ArgumentParser(prog='sam_classify_statistics',
                                 usage='sam_classify_statistics.py -s SAM -o OUTDIR -t ALIGN_TYPE',
                                 description='sam_classify_statistics_summary.')
parser.add_argument('-v', '--version', action='version', version='%(prog)s ' + __version__)
parser.add_argument('-s', '--sam', help='Input default sam format.', required=True)
parser.add_argument('-o', '--out_dir', help='Specify directory of output file.', required=True)
parser.add_argument('-t','--type',help='Alignment type.',required=False)
args = parser.parse_args()


if __name__ == '__main__':
    with open(args.sam, 'r') as f_1:
        sam = f_1.read().strip().split('\n')

    TP, FP, FN = 0,0,0

    for i in range(len(sam)):
        if not sam[i].startswith('@'):
            tmp = sam[i].split()
            if tmp[0].split('_')[0] == tmp[2]:
                TP += 1
            if tmp[0].split('_')[0] != tmp[2] and tmp[2] != '*':
                FP += 1
            if tmp[2] == '*':
                FN += 1

    total = TP + FP + FN
    TP_pct, FP_pct, FN_pct = str(round(float(TP)/float(total),3)), str(round(float(FP)/float(total),3)), str(round(float(FN)/float(total),3))
    precision = round(float(TP) / float(TP + FP),3)
    recall = round(float(TP) / float(TP + FN),3)
    beta = 1
    F_1 = str(round((1 + beta * beta) * (precision * recall) / (beta * beta * precision + recall),3))

    with open(os.path.join(args.out_dir, args.type + '_classify_stat.xls'), 'w') as classify_stat:
        classify_stat.write('\t'.join(['alignment_type', 'TP_pct', 'FP_pct', 'FN_pct', 'precision', 'recall', 'F_1']) + '\n')
        classify_stat.write('\t'.join([args.type,str(TP),str(FP),str(FN),str(precision),str(recall),F_1]) + '\n')
    print('\t'.join(['alignment_type', 'TP_pct', 'FP_pct', 'FN_pct', 'precision', 'recall', 'F_1']))
    print('\t'.join([args.type,str(TP),str(FP),str(FN),str(precision),str(recall),F_1]) + '\n')




