# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool
sRNAbench_dir="/research/xieyeming1/AASRA_2020/realistic_simulation/output/_06_msbar_sRNAbench/sRNAbench"
sRNAbench_out_convert_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/sRNAbench_out_convert.py"

single_corr_py="/research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/single_corr.py"
CORE_classify_stat_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/CORE_classify_statistics.py"
# parameter
mut_size=$1
anchor_type="sRNAbench_point_mut_${mut_size}nt" # [bt2_CG_anchor_1nt]

# input
query_dir="${proj_dir}/input/mut"
query="point_mut_${mut_size}nt_realistic_sim_one_line.fa"
sRNAbench_out_folder="point_mut_${mut_size}nt_realistic_sim_one_line"
full_miRNA_name="${proj_dir}/input/mirbase_name/mirbase_miRNA_one_line.fa"

# output
out_dir="${proj_dir}/output/_06_msbar_sRNAbench/${anchor_type}"

mkdir -p ${out_dir}
mkdir -p ${proj_dir}/script/log
(
java -jar ${sRNAbench_dir}/sRNAtoolboxDB/exec/sRNAbench.jar input=${query_dir}/${query} microRNA=mmu

cp /opt/sRNAtoolboxDB/out/${sRNAbench_out_folder}/stat/mappingStat.txt /opt/sRNAtoolboxDB/out/${sRNAbench_out_folder}/reads.annotation ${out_dir}

python ${sRNAbench_out_convert_py} -n ${full_miRNA_name} -f ${query_dir}/${query} -a /opt/sRNAtoolboxDB/out/${sRNAbench_out_folder}/reads.annotation -o ${out_dir}

# corr graph
python ${single_corr_py} -1 ${out_dir}/realistic_sim.fa_counts_reformat.txt -2 ${proj_dir}/input/realistic_standard_count.txt -t ${anchor_type} -o ${out_dir}

# compute TP FP FN
python ${CORE_classify_stat_py} -c ${out_dir}/realistic_sim.bam.featureCounts -o ${out_dir} -t ${anchor_type}
) 2>&1 | tee ${proj_dir}/script/log/_04_bt_no_anchor_alignment_${anchor_type}.log

