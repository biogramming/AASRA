#!/usr/bin/env python
"""
Calculate and plot the correlation graph between two files.

Copyright (C) 2016-2021 Chong Tang, Yeming Xie

This program is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 1 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
"""
__version__ = '1.1.0'
__author__ = 'Yeming Xie'
__date__ = 'Wed Oct 21 21:43:24 CST 2020'

import re
import operator
import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import seaborn as sns
import pandas as pd
import math
import subprocess
import re
import os
import argparse
import random

parser = argparse.ArgumentParser(prog='sRNAbench_out_convert_py', usage='python sRNAbench_out_convert.py -n INPUT_1 -c INPUT_2 -a OUTDIR', description='')
parser.add_argument('-v','--version', action='version', version='%(prog)s '+ __version__)
parser.add_argument('-n','--full_miRNA_name', help='full_miRNA_name fasta file',required=True)
parser.add_argument('-f','--realistic_sim', help='realistic_sim fasta file',required=True)
parser.add_argument('-a','--annotation',help='Specify directory of output reference.', required=True)
parser.add_argument('-o', '--out_dir', help='Specify directory of output file.', required=True)
args = parser.parse_args()

if __name__ == '__main__':
    with open(args.realistic_sim,'r') as f_1:
        realistic_sim = f_1.read().strip().split('\n')
    with open(args.full_miRNA_name,'r') as f_1:
        full_miRNA_name = f_1.read().strip().split('\n')
    with open(args.annotation,'r') as f_1:
        annotation = f_1.read().strip().split('\n')

    all_str_id_list = []
    seq_to_str_id_dict = {}
    for i in range(len(realistic_sim)):
        if realistic_sim[i].startswith('>'):
            sim_str_id = realistic_sim[i].split('_')[0][1:]
            if sim_str_id not in all_str_id_list:
                all_str_id_list.append(sim_str_id)
            seq_to_str_id_dict[realistic_sim[i+1]] = sim_str_id

    dash_to_str_id_dict = {}
    for i in range(len(full_miRNA_name)):
        if full_miRNA_name[i].startswith('>'):
            tmp = full_miRNA_name[i].split()
            dash_id = tmp[0][1:]
            str_id = tmp[1]
            dash_to_str_id_dict[dash_id] = str_id


    sRNAbench_id_to_count = {}

    CORE = open(os.path.join(args.out_dir, 'realistic_sim.bam.featureCounts'), 'w')
    a = 0
    for i in range(len(annotation)):
        tmp = annotation[i].split()
        dash_id_list = tmp[4].split('$')
        if tmp[0] in seq_to_str_id_dict:
            sRNAbench_str_id = seq_to_str_id_dict[tmp[0]]
            assign_str_list = []
            for j in range(len(dash_id_list)):
                assign_dash_id = dash_id_list[j].split('#')[1]
                assign_str_id = dash_to_str_id_dict[assign_dash_id]



                assign_str_list.append(assign_str_id)


            if 'antisense' in tmp[3]:
                CORE.write(('\t'.join([sRNAbench_str_id, 'Unassigned', '0', 'NA']) + '\n') * int(tmp[1]))
            else:
                if sRNAbench_str_id in all_str_id_list:
                    for k in range(len(assign_str_list)):
                        if sRNAbench_str_id == assign_str_list[k]:
                            CORE.write(('\t'.join([sRNAbench_str_id,'Assigned', str(len(assign_str_list)), assign_str_list[k]]) + '\n')* int(tmp[1]))
                        else:
                            CORE.write(('\t'.join([sRNAbench_str_id,'Assigned',str(len(assign_str_list)),assign_str_list[k]])+'\n') * int(tmp[1]))

                    assign_str_list_len = len(assign_str_list)
                    if assign_str_list_len == 1:
                        if assign_str_list[0] in sRNAbench_id_to_count:
                            sRNAbench_id_to_count[assign_str_list[0]] += int(tmp[1])
                        else:
                            sRNAbench_id_to_count[assign_str_list[0]] = int(tmp[1])

                    if assign_str_list_len != 1:
                        random_number = random.randint(1, assign_str_list_len) - 1
                        random_assign = assign_str_list[random_number]
                        CORE.write(('\t'.join([sRNAbench_str_id, 'Assigned', str(len(assign_str_list)), random_assign]) + '\n') * int(tmp[1]))
                        if random_assign in sRNAbench_id_to_count:
                            sRNAbench_id_to_count[random_assign] += int(tmp[1])
                        else:
                            sRNAbench_id_to_count[random_assign] = int(tmp[1])
                else:
                    CORE.write(('\t'.join([sRNAbench_str_id,'Unassigned','0','NA'])+'\n') * int(tmp[1]))
        else:
            CORE.write(('\t'.join([tmp[0],'Unassigned','0','NA'])+'\n')* int(tmp[1]))
    CORE.close()
    # write counts file
    with open(os.path.join(args.out_dir, 'realistic_sim.fa_counts_reformat.txt'), 'w') as counts:
        for k in sRNAbench_id_to_count:
            counts.write('\t'.join([k, str(sRNAbench_id_to_count[k])]) + '\n')



