# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool
AASRA='/research/xieyeming1/AASRA_2020/AASRA_rewrite/AASRA.py'
AASRA_index='/research/xieyeming1/AASRA_2020/AASRA_rewrite/AASRA-index.py'
single_corr_py="/research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/single_corr.py"
sam_classify_stat_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/sam_classify_statistics.py"
# parameter
anchor_type="bt2_no_anchor_0nt" # [bt2_CG_anchor_1nt]
query_l_anchor="0" # [1]
query_r_anchor="0" # [1]
bt_version="bt1" #[bt1,bt2]

# input
query_dir="${proj_dir}/input"
query='realistic_sim.fa'
ref_fa="mmumiRNA_reference.fa"

# output
out_dir="${proj_dir}/output/_04_bt_no_anchor_alignment/${anchor_type}"
ref_dir="${proj_dir}/output/ref"
mkdir -p ${out_dir}
mkdir -p ${ref_dir}/${anchor_type}
mkdir -p ${proj_dir}/script/log

(
# build ref
python ${AASRA_index} -p 4 -s -i ${proj_dir}/input/${ref_fa} -o ${ref_dir}/${anchor_type} -l NNNNNNNNNN -r NNNNNNNNNN -b bt2
sh ${ref_dir}/${anchor_type}/${ref_fa}_build_ref.sh

# AASRA align
python ${AASRA} -p 4 -f FASTA -i ${query_dir}/${query} -o ${out_dir} -l ${query_l_anchor} -r ${query_r_anchor} -x ${ref_dir}/${anchor_type}/anchored_${ref_fa} -b ${bt_version}
sh ${out_dir}/${query}_align.sh

# featurecount
echo "featureCounts -a ${ref_dir}/${anchor_type}/anchored_${ref_fa}.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/anchored_${query}.sam"
featureCounts -a ${ref_dir}/${anchor_type}/anchored_${ref_fa}.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/anchored_${query}.sam

tail -n +3 ${out_dir}/${query}_counts.txt|cut -f1,7 > ${out_dir}/${query}_counts_reformat.txt

# corr graph
python ${single_corr_py} -1 ${out_dir}/${query}_counts_reformat.txt -2 ${query_dir}/realistic_standard_count.txt \
-t ${anchor_type} -o ${out_dir}
) 2>&1 | tee ${proj_dir}/script/log/_02_bt_based_alignment_${anchor_type}.log

# compute TP FP FN
python ${sam_classify_stat_py} -s ${out_dir}/anchored_${query}.sam -o ${out_dir} -t ${anchor_type}