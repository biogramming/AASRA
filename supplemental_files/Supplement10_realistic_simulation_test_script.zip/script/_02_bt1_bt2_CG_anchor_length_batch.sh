sh _02_bt_based_alignment.sh bt1_CG_anchor_4nt 4 4 bt1
sh _02_bt_based_alignment.sh bt1_CG_anchor_3nt 3 3 bt1
sh _02_bt_based_alignment.sh bt1_CG_anchor_2nt 2 2 bt1
sh _02_bt_based_alignment.sh bt1_CG_anchor_1nt 1 1 bt1
sh _02_bt_based_alignment.sh bt1_CG_anchor_5nt 5 5 bt1
sh _02_bt_based_alignment.sh bt1_CG_anchor_6nt 6 6 bt1

sh _02_bt_based_alignment.sh bt2_CG_anchor_1nt 1 1 bt2
sh _02_bt_based_alignment.sh bt2_CG_anchor_2nt 2 2 bt2
sh _02_bt_based_alignment.sh bt2_CG_anchor_3nt 3 3 bt2
sh _02_bt_based_alignment.sh bt2_CG_anchor_4nt 4 4 bt2
sh _02_bt_based_alignment.sh bt2_CG_anchor_5nt 5 5 bt2
sh _02_bt_based_alignment.sh bt2_CG_anchor_6nt 6 6 bt2
