#!/usr/bin/env python
"""
Calculate and plot the correlation graph between two files.

Copyright (C) 2016-2021 Chong Tang, Yeming Xie

This program is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 1 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
"""
__version__ = '1.0.0'
__author__ = 'Yeming Xie'
__date__ = 'Mon Feb 22 17:41:21 CST 2021'

import re
import operator
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['agg.path.chunksize'] = 10000
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import math
import subprocess
import re
import os
import argparse
import random

parser = argparse.ArgumentParser(prog='realistic_sim.py',
                                 usage='python realistic_sim.py -1 INPUT_1 -2 INPUT_2 -o OUTDIR',
                                 description='Calculate and plot the correlation graph between two files.')
parser.add_argument('-v', '--version', action='version', version='%(prog)s ' + __version__)
parser.add_argument('-x', '--reference', help='sRNA Reference file.', required=True)
parser.add_argument('-o', '--out_dir', help='Specify directory of output reference.', required=True)

args = parser.parse_args()

def compute_histogram_bins(data, desired_bin_size):
    min_val = np.min(data)
    max_val = np.max(data)
    min_boundary = -1.0 * (min_val % desired_bin_size - min_val)
    max_boundary = max_val - max_val % desired_bin_size + desired_bin_size
    n_bins = int((max_boundary - min_boundary) / desired_bin_size) + 1
    bins = np.linspace(min_boundary, max_boundary, n_bins)
    return bins

if __name__ == '__main__':
    with open(args.reference, 'r') as f_1:
        ref = f_1.read().strip().split('\n')

    realistic_standard_count = open(os.path.join(args.out_dir,'realistic_standard_count.txt'), 'w')

    raw_pre_len_list = []
    mat_len_list = []
    pre_len_list = []

    realistic_dict = {}

    for i in range(len(ref)):
        if ref[i].startswith('>MIMAT'):
            mat_id = ref[i][1:]
            mat_seq = ref[i+1]

            rand_count = random.randint(1,100)
            realistic_standard_count.write(''.join([mat_id, '\t', str(rand_count), '\n']))

            for j in range(1,rand_count):
                mat_len_list.append(len(mat_seq))
                realistic_dict['>' + mat_id + '_' + str(j)] = mat_seq

        elif ref[i].startswith('>'):
            pre_id = ref[i][1:]
            pre_seq = ref[i+1]
            raw_pre_len_list.append(len(pre_seq))

            rand_count = random.randint(1,100)
            realistic_standard_count.write(''.join([pre_id, '\t', str(rand_count), '\n']))
            for j in range(1,rand_count):
                rand_len = int(np.random.normal(60, 3))
                if rand_len > len(pre_seq):
                    rand_len = len(pre_seq)
                elif len(pre_seq) > 90:
                    rand_len = len(pre_seq) - 50

                rand_start = random.randint(1, len(pre_seq) - rand_len + 1)
                pre_seq_sub = pre_seq[rand_start - 1: rand_start - 1 + rand_len]
                pre_len_list.append(len(pre_seq_sub))
                realistic_dict['>' + pre_id + '_' + str(j)] = pre_seq_sub

    realistic_standard_count.close()

    # len dist
    mat_len_arr = np.asarray(mat_len_list)
    pre_len_arr = np.asarray(pre_len_list)
    raw_pre_len_arr = np.asarray(raw_pre_len_list)
    print(mat_len_arr)

    # mat sim vs pre sim
    plt.hist(mat_len_arr, compute_histogram_bins(mat_len_arr,1), density=True, facecolor='red', alpha=0.5, edgecolor='black')
    plt.hist(pre_len_arr, compute_histogram_bins(pre_len_arr,1), density=True, facecolor='green', alpha=0.5,edgecolor='black')
    red,green = mpatches.Patch(color='red', label='simulated mature miRNA reads'),mpatches.Patch(color='green', label='simulated premature miRNA reads')
    plt.legend(handles=[red,green])
    plt.tight_layout()
    plt.show()
    plt.savefig(os.path.join(args.out_dir,'mat_vs_pre_len_dist.pdf'),dpi=600)
    plt.savefig(os.path.join(args.out_dir,'mat_vs_pre_len_dist.png'),dpi=600)
    plt.close()

    # pre raw vs pre sim
    plt.hist(raw_pre_len_arr, compute_histogram_bins(raw_pre_len_arr,1), density=True, facecolor='darkviolet', alpha=0.5, edgecolor='black')
    plt.hist(pre_len_arr, compute_histogram_bins(pre_len_arr,1), density=True, facecolor='green', alpha=0.5,edgecolor='black')
    darkviolet,green = mpatches.Patch(color='darkviolet', label='premature miRNA reference'),mpatches.Patch(color='green', label='simulated premature miRNA reads')
    plt.legend(handles=[darkviolet,green])
    plt.show()
    plt.savefig(os.path.join(args.out_dir,'pre_raw_vs_sim_len_dist.pdf'),dpi=600)
    plt.savefig(os.path.join(args.out_dir,'pre_raw_vs_sim_len_dist.png'),dpi=600)
    plt.close()

    # sampling and output reads for snp, indel, overhang, noVar
    count_sum = len(realistic_dict)
    count_snp = int(count_sum * 8E-4)
    count_indel = int(count_sum * 1E-5)
    count_overhang = int(count_sum * 4E-3)
    count_noVar = count_sum - count_snp - count_indel - count_overhang

    k_list = list(realistic_dict.keys())
    random.shuffle(k_list)
    print(count_sum)
    with open(os.path.join(args.out_dir,'for_snp.fa'), 'w') as snp:
        for k in k_list[0 : count_snp]:
            snp.write(k + '\n' + realistic_dict[k] + '\n')

    with open(os.path.join(args.out_dir,'for_indel.fa'), 'w') as indel:
        for k in k_list[count_snp : count_snp + count_indel]:
            indel.write(k + '\n' + realistic_dict[k] + '\n')

    with open(os.path.join(args.out_dir,'noVar.fa'), 'w') as noVar:
        for k in k_list[count_snp + count_indel : count_snp + count_indel + count_noVar]:
            noVar.write(k + '\n' + realistic_dict[k] + '\n')

    with open(os.path.join(args.out_dir,'overhang.fa'), 'w') as overhang:
        for k in k_list[count_snp + count_indel + count_noVar : count_snp + count_indel + count_noVar + count_overhang]:
            overhang_num = random.randint(1,4)
            overhang_base = ''.join(random.choices('ATCG', k=overhang_num))
            overhang_pos = random.randint(0,1)
            if overhang_pos == 0:
                overhang.write(k + '\n' + overhang_base + realistic_dict[k] + '\n')
            if overhang_pos == 1:
                overhang.write(k + '\n' + realistic_dict[k] + overhang_base +'\n')
