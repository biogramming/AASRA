# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool
single_corr_py="/research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/single_corr.py"
CORE_classify_stat_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/CORE_classify_statistics.py"
# parameter
anchor_type="shortstack" # [bt2_CG_anchor_1nt]

# input
query_dir="${proj_dir}/input"
query='realistic_sim.fa'
saf='/research/xieyeming1/AASRA_2020/realistic_simulation/input/bt2_genome_align/new_saf/mmumiRNA_reference.fa.sam.saf'

# output
out_dir="${proj_dir}/output/_04_bt_no_anchor_alignment/${anchor_type}"

# mkdir -p ${out_dir}
mkdir -p ${proj_dir}/script/log
(
ShortStack --readfile ${query_dir}/${query} --genomefile ${query_dir}/bt2_genome_align/genome.fa --outdir ${out_dir}

echo "featureCounts -O -R CORE -a ${saf} -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/realistic_sim.bam"
featureCounts -O -R CORE -a ${saf} -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/realistic_sim.bam
# featurecount
# echo "featureCounts -a ${query_dir}/bt2_genome_align/miRNA_SAF.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/${query}.sam"
# featureCounts -a ${query_dir}/bt2_genome_align/miRNA_SAF.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/${query}.sam

tail -n +3 ${out_dir}/${query}_counts.txt|cut -f1,7 > ${out_dir}/${query}_counts_reformat.txt

# corr graph
python ${single_corr_py} -1 ${out_dir}/${query}_counts_reformat.txt -2 ${query_dir}/realistic_standard_count.txt -t ${anchor_type} -o ${out_dir}

# compute TP FP FN
python ${CORE_classify_stat_py} -c ${out_dir}/realistic_sim.bam.featureCounts -o ${out_dir} -t ${anchor_type}
) 2>&1 | tee ${proj_dir}/script/log/_04_bt_no_anchor_alignment_${anchor_type}.log

