# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool

AASRA_index='/research/xieyeming1/AASRA_2020/AASRA_rewrite/AASRA-index.py'
single_corr_py="/research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/single_corr.py"
sam_classify_stat_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/sam_classify_statistics.py"
# parameter
anchor_type="bt2_no_anchor_ref_no_padding" # [bt2_CG_anchor_1nt]
#query_l_anchor="$2" # [1]
#query_r_anchor="$3" # [1]
#bt_version="$4" #[bt1,bt2]

# input
query_dir="${proj_dir}/input"
query='realistic_sim.fa'
ref_fa="mmumiRNA_reference.fa"

# output
out_dir="${proj_dir}/output/_04_bt_no_anchor_alignment/${anchor_type}"
ref_dir="${proj_dir}/output/ref"
mkdir -p ${out_dir}
mkdir -p ${ref_dir}/${anchor_type}
mkdir -p ${proj_dir}/script/log

(
# build ref
python ${AASRA_index} -p 4 -s -i ${proj_dir}/input/${ref_fa} -o ${ref_dir}/${anchor_type} -l 0 -r 0 -b bt2
sh ${ref_dir}/${anchor_type}/${ref_fa}_build_ref.sh

# bt2 align
bowtie2 --norc -N 1 -L 16 -i S,0,0.2 -f -p 4 -x ${ref_dir}/${anchor_type}/anchored_${ref_fa} -U ${query_dir}/${query} -S ${out_dir}/${query}.sam

# featurecount
echo "featureCounts -a ${ref_dir}/${anchor_type}/anchored_${ref_fa}.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/${query}.sam"
featureCounts -a ${ref_dir}/${anchor_type}/anchored_${ref_fa}.saf -F SAF -o ${out_dir}/${query}_counts.txt ${out_dir}/${query}.sam

tail -n +3 ${out_dir}/${query}_counts.txt|cut -f1,7 > ${out_dir}/${query}_counts_reformat.txt

# corr graph
python ${single_corr_py} -1 ${out_dir}/${query}_counts_reformat.txt -2 ${query_dir}/realistic_standard_count.txt \
-t ${anchor_type} -o ${out_dir}
) 2>&1 | tee ${proj_dir}/script/log/_02_bt_based_alignment_${anchor_type}.log

# compute TP FP FN
python ${sam_classify_stat_py} -s ${out_dir}/${query}.sam -o ${out_dir} -t ${anchor_type}