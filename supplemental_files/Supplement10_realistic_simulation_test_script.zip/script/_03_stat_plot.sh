# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool
stat_plot_py="/research/xieyeming1/AASRA_2020/realistic_simulation/script/stat_plot.py"

# parameter

# input


# output
out_stat="${proj_dir}/report/stat"

mkdir -p ${out_stat}

cat ${proj_dir}/output/_02_bt_based_alignment/bt2_CG_anchor_1nt/*classify_stat.xls |head -1 > ${out_stat}/header.tmp
find ${proj_dir}/output/_02_bt_based_alignment -type f -name *classify_stat.xls|xargs cat|awk 'NR % 2 == 0' > ${out_stat}/classify_stat_sum.xls.tmp

cat ${out_stat}/header.tmp ${out_stat}/classify_stat_sum.xls.tmp > ${out_stat}/_02_bt_based_alignment_classify_stat_sum.xls

rm ${out_stat}/*.tmp

python ${stat_plot_py} -i ${out_stat}/_02_bt_based_alignment_classify_stat_sum.xls -o ${out_stat}