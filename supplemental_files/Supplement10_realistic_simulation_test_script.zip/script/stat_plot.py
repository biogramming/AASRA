#!/usr/bin/env python
"""
Calculate and plot the correlation graph between two files.

Copyright (C) 2016-2021 Chong Tang, Yeming Xie

This program is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 1 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
"""
__version__ = '1.0.0'
__author__ = 'Yeming Xie'
__date__ = 'Mon Feb 22 17:41:21 CST 2021'

import re
import operator
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['agg.path.chunksize'] = 10000
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import seaborn as sns
import pandas as pd
import math
import subprocess
import re
import os
import argparse
import random


parser = argparse.ArgumentParser(prog='stat_plot.py',
                                 usage='stat_plot.py -i TABLE -o OUTDIR',
                                 description='Barplot and dotplot of all alignments stats.')
parser.add_argument('-v', '--version', action='version', version='%(prog)s ' + __version__)
parser.add_argument('-i', '--input_xls', help='Input table file.', required=True)
parser.add_argument('-o', '--out_dir', help='Specify directory of output file.', required=True)
args = parser.parse_args()


if __name__ == '__main__':
    file_name = os.path.split(args.input_xls)[-1]
    df = pd.read_csv(args.input_xls,sep='\t')

    plt.hlines(y=df.alignment_type, xmin=0,xmax=1, color='gray', alpha=0.7, linewidth=1, linestyles='dashdot')

    blue_dot = plt.scatter(y=df.alignment_type, x=df.precision, s=15, color='blue', alpha=0.7)
    red_dot = plt.scatter(y=df.alignment_type, x=df.recall, s=15, color='red', alpha=0.7)
    black_dot = plt.scatter(y=df.alignment_type, x=df.F_1, s=15, color='black', alpha=0.7)

    plt.legend([blue_dot,red_dot, black_dot], ['precision','recall','F1_score'],bbox_to_anchor=(1.04,0.5), loc="center left")
    plt.tight_layout()
    plt.show()
    plt.savefig(os.path.join(args.out_dir,file_name + '_precision_recall.pdf'),dpi=600)
    plt.savefig(os.path.join(args.out_dir,file_name + '_precision_recall.png'),dpi=600)
    plt.close()


    width = 0.4
    TP = plt.barh(df.alignment_type,df.TP/(df.TP+df.FP+df.FN), width,color='darkgreen',edgecolor='black')
    FP = plt.barh(df.alignment_type,df.FP/(df.TP+df.FP+df.FN), width,color='orange',edgecolor='black',left=df.TP/(df.TP+df.FP+df.FN))
    FN = plt.barh(df.alignment_type,df.FN/(df.TP+df.FP+df.FN), width,color='grey',edgecolor='black',left=df.TP/(df.TP+df.FP+df.FN)+df.FP/(df.TP+df.FP+df.FN))
    plt.legend([TP, FP, FN], ['TP', 'FP', 'FN'],bbox_to_anchor=(1.04,0.5), loc="center left")
    plt.tight_layout()
    plt.show()
    plt.savefig(os.path.join(args.out_dir,file_name + 'TP_FP_FN.pdf'),dpi=600)
    plt.savefig(os.path.join(args.out_dir,file_name + 'TP_FP_FN.png'),dpi=600)
    plt.close()


