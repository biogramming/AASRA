# project dir
proj_dir="/research/xieyeming1/AASRA_2020/realistic_simulation"
# tool
realistic_sim_py="${proj_dir}/script/realistic_sim.py"
multi_to_one_line_fasta_yeming_py="/research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py"
# parameter

# input
miRNA_ref="${proj_dir}/input/mmumiRNA_reference.fa"
# output
out_dir="${proj_dir}/input"

python ${realistic_sim_py} -x ${miRNA_ref} -o ${out_dir}

cat ${out_dir}/for_snp.fa|msbar -filter -count 2 -point 4 > ${out_dir}/snp.fa

cat ${out_dir}/for_indel.fa|msbar -filter -block 1 -minimum 1 -maximum 4 > ${out_dir}/indel.fa

cat ${out_dir}/indel.fa ${out_dir}/snp.fa ${out_dir}/noVar.fa ${out_dir}/overhang.fa > ${out_dir}/realistic_sim.fa.tmp

python ${multi_to_one_line_fasta_yeming_py} ${out_dir}/realistic_sim.fa.tmp ${out_dir}/realistic_sim.fa