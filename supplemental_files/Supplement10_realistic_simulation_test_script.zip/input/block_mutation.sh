cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 4 -maximum 4 > block_mut_4nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 3 -maximum 3 > block_mut_3nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 2 -maximum 2 > block_mut_2nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 1 -maximum 1 > block_mut_1nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 5 -maximum 5 > block_mut_5nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -block 1 -minimum 6 -maximum 6 > block_mut_6nt_realistic_sim.fa

cat ../realistic_sim.fa |msbar -filter -count 1 -point 1 > point_mut_1nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -count 2 -point 1 > point_mut_2nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -count 3 -point 1 > point_mut_3nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -count 4 -point 1 > point_mut_4nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -count 5 -point 1 > point_mut_5nt_realistic_sim.fa
cat ../realistic_sim.fa |msbar -filter -count 6 -point 1 > point_mut_6nt_realistic_sim.fa

python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_6nt_realistic_sim.fa block_mut_6nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_5nt_realistic_sim.fa block_mut_5nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_4nt_realistic_sim.fa block_mut_4nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_3nt_realistic_sim.fa block_mut_3nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_2nt_realistic_sim.fa block_mut_2nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py block_mut_1nt_realistic_sim.fa block_mut_1nt_realistic_sim_one_line.fa

python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_6nt_realistic_sim.fa point_mut_6nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_5nt_realistic_sim.fa point_mut_5nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_4nt_realistic_sim.fa point_mut_4nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_3nt_realistic_sim.fa point_mut_3nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_2nt_realistic_sim.fa point_mut_2nt_realistic_sim_one_line.fa
python /research/xieyeming1/AASRA_2020/proof_of_concept_simulation/script/multi_to_one_line_fasta_yeming.py point_mut_1nt_realistic_sim.fa point_mut_1nt_realistic_sim_one_line.fa